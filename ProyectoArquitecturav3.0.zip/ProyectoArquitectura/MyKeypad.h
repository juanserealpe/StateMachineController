#ifndef MyKEYPAD_H
#define MyKEYPAD_H

#include <Arduino.h>
#include <Keypad.h>

extern Keypad keypad;

void setupKeypad();

#endif
