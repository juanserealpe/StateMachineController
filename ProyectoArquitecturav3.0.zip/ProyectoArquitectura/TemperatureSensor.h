#ifndef TEMPERATURE_H
#define TEMPERATURE_H

#include <Arduino.h>

void setupTemperature();
void updateTemperature();
extern float currentTemperature;

#endif
